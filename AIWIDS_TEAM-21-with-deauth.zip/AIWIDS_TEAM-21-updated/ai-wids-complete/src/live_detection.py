#!/usr/bin/env python3
"""
===============================================================================
AI-WIDS LIVE DETECTION - WITH DEAUTH ATTACK DETECTION
===============================================================================
FEATURES:
1. Evil Twin detection via ML model (EvilTwinDetector neural network)
2. Deauthentication / Disassociation flood detection (DeauthDetector)
3. Real-time Flask + SocketIO web dashboard
4. Colour-coded terminal output for operators
===============================================================================
"""

# ===========================
# IMPORTS
# ===========================
import json
import time
import threading
import subprocess
from collections import defaultdict, deque
from datetime import datetime

import numpy as np
import torch
import torch.nn as nn
from scapy.all import Dot11, Dot11Elt, PcapReader
from flask import Flask, render_template_string
from flask_socketio import SocketIO
import colorama
from colorama import Fore, Style, Back
from deauth_detector import DeauthDetector           # NEW: Deauth flood detector

colorama.init(autoreset=True)

# ===========================
# CONFIGURATION
# ===========================
OPENWRT_IP          = "192.168.32.55"
INTERFACE           = "phy0-mon0"
PRINT_INTERVAL      = 2
ALERT_HISTORY_LIMIT = 50
NET_HISTORY_LIMIT   = 200

# ===========================
# MOBILE OUI DATABASE
# ===========================
MOBILE_OUIS = [
    "02:00:00", "06:00:00", "0a:00:00", "0e:00:00",
    "12:00:00", "16:00:00", "1a:00:00", "1e:00:00",
    "f6:55:a8", "ee:55:a8", "fa:c6:f7", "fe:55:a8",
    "f2:55:a8", "ea:55:a8", "e6:55:a8", "e2:55:a8",
    "92:74:fb", "a2:74:fb", "b2:74:fb", "c2:74:fb",
    "82:74:fb", "72:74:fb", "62:74:fb", "52:74:fb",
    "34:02:86", "44:4e:1a", "64:a2:f9", "78:f7:be",
    "ac:5f:3e", "e8:50:8b", "f8:d0:ac",
    "34:80:b3", "50:8f:4c", "74:23:44", "78:02:f8",
    "c4:0b:cb", "f8:a4:5f",
    "00:9a:cd", "18:31:bf", "20:47:ed", "54:25:ea",
    "a4:d5:78", "c8:85:50",
    "38:d5:7a", "ac:37:43",
    "f4:f5:24", "f8:cf:c5",
]

# ===========================
# GLOBAL STATE
# ===========================
class GlobalState:
    def __init__(self):
        self.ssid_map        = defaultdict(set)
        self.bssid_to_ssid   = {}
        self.packet_count    = defaultdict(int)
        self.alerts          = deque(maxlen=ALERT_HISTORY_LIMIT)
        self.network_history = deque(maxlen=NET_HISTORY_LIMIT)
        self.net_confidence  = defaultdict(float)
        self.stats = {
            'total_packets'     : 0,
            'normal_packets'    : 0,
            'evil_twin_packets' : 0,
            'deauth_packets'    : 0,     # NEW
            'disassoc_packets'  : 0,     # NEW
            'alerts_count'      : 0,
            'deauth_alerts'     : 0,     # NEW
            'mobile_hotspots'   : 0,
            'unique_ssids'      : 0,
            'unique_bssids'     : 0,
            'conflict_ssids'    : 0,
        }
        self.lock        = threading.Lock()
        self.last_update = time.time()

state           = GlobalState()
deauth_detector = DeauthDetector()   # NEW: single shared instance

# ===========================
# NEURAL NETWORK
# ===========================
class EvilTwinDetector(nn.Module):
    def __init__(self, input_size):
        super().__init__()
        self.fc1     = nn.Linear(input_size, 128)
        self.fc2     = nn.Linear(128, 64)
        self.fc3     = nn.Linear(64, 32)
        self.fc4     = nn.Linear(32, 2)
        self.relu    = nn.ReLU()
        self.dropout = nn.Dropout(0.3)

    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.relu(self.fc2(x))
        x = self.dropout(x)
        x = self.relu(self.fc3(x))
        return self.fc4(x)

# ===========================
# HELPERS
# ===========================
def is_mobile(bssid):
    if not bssid or len(bssid) < 8:
        return False
    bssid = bssid.lower()
    if bssid[:8] in MOBILE_OUIS:
        return True
    try:
        if int(bssid[:2], 16) & 0x02:
            return True
    except Exception:
        pass
    if bssid[1] in ['2', '6', 'a', 'e']:
        return True
    return False

def is_valid_ssid(ssid):
    if not ssid:
        return False
    if ssid == "UNKNOWN" or ssid.strip() == "":
        return False
    if all(c == '\x00' for c in ssid):
        return False
    return True

def safe_decode_ssid(raw):
    if raw is None:
        return None
    try:
        ssid = raw.decode('utf-8', errors='ignore') if isinstance(raw, (bytes, bytearray)) else str(raw)
    except Exception:
        return None
    ssid = ssid.replace('\x00', '').strip()
    return ssid if is_valid_ssid(ssid) else None

def get_device_name(bssid):
    if not bssid:
        return 'UNKNOWN'
    return 'Mobile Hotspot' if is_mobile(bssid) else 'Router/AP'

def extract_features(pkt, deauth_buffer, beacon_buffer):
    features = {}
    features['frame_length']  = len(bytes(pkt))
    features['frame_type']    = pkt.type    if pkt.haslayer(Dot11) else 0
    features['frame_subtype'] = pkt.subtype if pkt.haslayer(Dot11) else 0

    is_beacon  = int(pkt.haslayer(Dot11) and pkt.type == 0 and pkt.subtype == 8)
    is_deauth  = int(pkt.haslayer(Dot11) and pkt.type == 0 and pkt.subtype == 12)
    is_disassoc= int(pkt.haslayer(Dot11) and pkt.type == 0 and pkt.subtype == 10)

    features['is_mgmt']    = int(pkt.haslayer(Dot11) and pkt.type == 0)
    features['is_beacon']  = is_beacon
    features['is_deauth']  = is_deauth
    features['is_disassoc']= is_disassoc

    ssid = bssid = None
    if pkt.haslayer(Dot11):
        bssid = pkt.addr3 or pkt.addr2
        if is_beacon and pkt.haslayer(Dot11Elt):
            elt = pkt.getlayer(Dot11Elt)
            while elt is not None:
                if getattr(elt, 'ID', None) == 0:
                    ssid = safe_decode_ssid(getattr(elt, 'info', None))
                    break
                elt = elt.payload.getlayer(Dot11Elt)

    features['ssid']  = ssid if is_valid_ssid(ssid) else None
    features['bssid'] = bssid
    deauth_buffer.append(is_deauth)
    beacon_buffer.append(is_beacon)
    features['deauth_rate'] = sum(deauth_buffer) / max(1, len(deauth_buffer)) * 10
    features['beacon_rate'] = sum(beacon_buffer) / max(1, len(beacon_buffer)) * 10
    return features

# ===========================
# WEB DASHBOARD
# ===========================
app = Flask(__name__)
app.config['SECRET_KEY'] = 'ai-wids-secret'
socketio = SocketIO(app, cors_allowed_origins='*', async_mode='threading')

DASHBOARD_HTML = """<!DOCTYPE html>
<html>
<head>
    <title>AI-WIDS Live Dashboard</title>
    <script src="https://cdn.socket.io/4.5.0/socket.io.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #0a0e27; color: #eee; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; text-align: center; }
        .header h1 { font-size: 2em; margin-bottom: 5px; }
        .status-live { width: 12px; height: 12px; border-radius: 50%; background: #2ed573; display: inline-block; animation: pulse 2s infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }
        .container { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; padding: 20px; max-width: 1400px; margin: 0 auto; }
        .card { background: #1a1f3a; border-radius: 10px; padding: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.5); }
        .card h2 { color: #00d4ff; margin-bottom: 15px; border-bottom: 2px solid #00d4ff; padding-bottom: 10px; }
        .stat-box { display: flex; justify-content: space-between; padding: 12px; background: #0f1729; border-radius: 5px; margin: 10px 0; }
        .stat-label { color: #aaa; }
        .stat-value { font-weight: bold; font-size: 1.3em; }
        .alert { background: #ff4757; color: white; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .alert-mobile { background: #ffa502; }
        .alert-deauth  { background: #8e44ad; }
        #alerts-list { max-height: 400px; overflow-y: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #2c3e50; }
        th { background: #0f1729; color: #00d4ff; font-weight: bold; }
        tr:hover { background: #0f1729; }
        .type-evil-twin { color: #ff4757; font-weight: bold; }
        .type-mobile { color: #ffa502; font-weight: bold; }
        .type-normal { color: #2ed573; }
        .type-deauth { color: #bf5fff; font-weight: bold; }
        .timestamp { color: #ddd; font-size: 0.85em; }
    </style>
</head>
<body>
    <div class="header">
        <h1>&#x1F6E1;&#xFE0F; AI-WIDS Live Dashboard</h1>
        <p><span class="status-live"></span> Real-time Evil Twin + Deauth Detection</p>
    </div>
    <div class="container">
        <div class="card">
            <h2>&#x1F4CA; Statistics</h2>
            <div class="stat-box"><span class="stat-label">Total Packets</span><span class="stat-value" id="total">0</span></div>
            <div class="stat-box"><span class="stat-label">Normal</span><span class="stat-value" style="color:#2ed573" id="normal">0</span></div>
            <div class="stat-box"><span class="stat-label">Evil Twin</span><span class="stat-value" style="color:#ff4757" id="evil">0</span></div>
            <div class="stat-box"><span class="stat-label">Deauth Frames</span><span class="stat-value" style="color:#bf5fff" id="deauth">0</span></div>
            <div class="stat-box"><span class="stat-label">Disassoc Frames</span><span class="stat-value" style="color:#bf5fff" id="disassoc">0</span></div>
            <div class="stat-box"><span class="stat-label">Deauth Alerts</span><span class="stat-value" style="color:#ff6348" id="deauth_alerts">0</span></div>
            <div class="stat-box"><span class="stat-label">Mobile Hotspots</span><span class="stat-value" style="color:#ffa502" id="mobile">0</span></div>
            <div class="stat-box"><span class="stat-label">Total Alerts</span><span class="stat-value" style="color:#ff6348" id="alerts">0</span></div>
            <div class="stat-box"><span class="stat-label">Conflict SSIDs</span><span class="stat-value" style="color:#ff9f43" id="conflicts">0</span></div>
        </div>
        <div class="card">
            <h2>&#x1F6A8; Recent Alerts</h2>
            <div id="alerts-list"></div>
        </div>
        <div class="card" style="grid-column: span 2;">
            <h2>&#x1F310; Detected Networks</h2>
            <table>
                <thead>
                    <tr><th>SSID</th><th>Packets</th><th>BSSIDs</th><th>Type</th><th>Confidence (%)</th></tr>
                </thead>
                <tbody id="networks"></tbody>
            </table>
        </div>
    </div>
    <script>
        const socket = io();
        let lastStats = null, lastNetworks = [], lastRefresh = Date.now();
        function renderStats(d) {
            document.getElementById('total').textContent         = d.total_packets     ?? 0;
            document.getElementById('normal').textContent        = d.normal_packets    ?? 0;
            document.getElementById('evil').textContent          = d.evil_twin_packets ?? 0;
            document.getElementById('deauth').textContent        = d.deauth_packets    ?? 0;
            document.getElementById('disassoc').textContent      = d.disassoc_packets  ?? 0;
            document.getElementById('deauth_alerts').textContent = d.deauth_alerts     ?? 0;
            document.getElementById('mobile').textContent        = d.mobile_hotspots   ?? 0;
            document.getElementById('alerts').textContent        = d.alerts_count      ?? 0;
            document.getElementById('conflicts').textContent     = d.conflict_ssids    ?? 0;
        }
        function renderNetworks(data) {
            document.getElementById('networks').innerHTML = data.map(net => {
                const baseType = String(net.type || '').split(' ')[0].toLowerCase();
                return `<tr><td>${net.ssid}</td><td>${net.packets}</td><td>${net.bssids}</td>
                        <td class="type-${baseType}">${net.type}</td>
                        <td>${Number(net.confidence || 0).toFixed(1)}%</td></tr>`;
            }).join('');
        }
        function renderAlert(data) {
            const div   = document.getElementById('alerts-list');
            const el    = document.createElement('div');
            if (data.is_deauth) {
                el.className = 'alert alert-deauth';
                el.innerHTML = `<strong>&#x26A1; ${data.type}</strong><br>Sender: ${data.bssid}<br>Target: ${data.target}<br>Frames: ${data.frame_count}<br><span class="timestamp">${data.time}</span>`;
            } else {
                el.className = data.is_mobile ? 'alert alert-mobile' : 'alert';
                el.innerHTML = `<strong>${data.type}</strong><br>SSID: ${data.ssid || 'N/A'}<br>BSSID: ${data.bssid}<br><span class="timestamp">${data.time}</span>`;
            }
            div.insertBefore(el, div.firstChild);
            while (div.children.length > 50) div.lastChild.remove();
        }
        socket.on('connect',  () => { if (lastStats) renderStats(lastStats); if (lastNetworks.length) renderNetworks(lastNetworks); });
        socket.on('stats',    d  => { lastStats = d; renderStats(d); });
        socket.on('networks', d  => { lastNetworks = d; renderNetworks(d); });
        socket.on('alert',    d  => renderAlert(d));
        setInterval(() => { if (Date.now() - lastRefresh > 15000) { socket.emit('client_ping', {time: Date.now()}); lastRefresh = Date.now(); } }, 5000);
    </script>
</body>
</html>"""

@app.route('/')
def index():
    return render_template_string(DASHBOARD_HTML)

# ===========================
# DASHBOARD WORKER
# ===========================
def dashboard_worker():
    while True:
        time.sleep(PRINT_INTERVAL)
        with state.lock:
            networks = []
            conflict_count = 0
            for ssid, bssids in state.ssid_map.items():
                if not ssid:
                    continue
                total_pkts = sum(state.packet_count.get((ssid, b), 0) for b in bssids)
                conflict   = len(bssids) > 1
                if conflict:
                    conflict_count += 1
                evil_prob  = float(state.net_confidence.get(ssid, 0.0))
                is_ml_evil = evil_prob >= 0.5
                if conflict:
                    net_type, confidence = 'EVIL-TWIN (Conflict)', 100.0
                elif is_ml_evil:
                    net_type, confidence = 'EVIL-TWIN (ML)', round(evil_prob * 100.0, 1)
                elif any(is_mobile(b) for b in bssids):
                    net_type, confidence = 'MOBILE', 100.0
                else:
                    net_type, confidence = 'NORMAL', round((1.0 - evil_prob) * 100.0, 1)
                networks.append({'ssid': ssid, 'packets': total_pkts, 'bssids': len(bssids), 'type': net_type, 'confidence': confidence})
                state.network_history.append({'time': datetime.now().strftime('%H:%M:%S'), 'ssid': ssid, 'type': net_type, 'confidence': confidence, 'bssids': len(bssids), 'packets': total_pkts})

            networks.sort(key=lambda n: (n['type'] not in ['EVIL-TWIN (Conflict)', 'EVIL-TWIN (ML)'], -n['confidence'], -n['packets']))
            state.stats['unique_ssids']   = len(state.ssid_map)
            state.stats['unique_bssids']  = len(state.bssid_to_ssid)
            state.stats['conflict_ssids'] = conflict_count

            # Sync deauth stats from detector
            ds = deauth_detector.get_stats()
            state.stats['deauth_packets']   = ds['total_deauth_frames']
            state.stats['disassoc_packets'] = ds['total_disassoc_frames']
            state.stats['deauth_alerts']    = ds['total_deauth_alerts']

            socketio.emit('stats',    dict(state.stats))
            socketio.emit('networks', networks)

def build_alert(alert_type, ssid, bssid, is_mobile_device):
    return {'type': alert_type, 'ssid': ssid, 'bssid': bssid, 'is_mobile': is_mobile_device, 'is_deauth': False, 'time': datetime.now().strftime('%H:%M:%S')}

# ===========================
# MAIN
# ===========================
def main():
    print(f"\n{Back.BLUE}{Fore.WHITE} AI-WIDS LIVE DETECTION - EVIL TWIN + DEAUTH {Style.RESET_ALL}\n")
    print(f"{Fore.CYAN}[1/3] Loading model...{Style.RESET_ALL}")
    checkpoint    = torch.load('../data/model/wireless_ids.pt', map_location='cpu')
    model         = EvilTwinDetector(checkpoint['scaler'].n_features_in_)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()
    scaler        = checkpoint['scaler']
    feature_order = checkpoint.get('feature_order', list(range(10)))
    print(f"  ✓ Model loaded\n")

    print(f"{Fore.CYAN}[2/3] Starting dashboard...{Style.RESET_ALL}")
    print(f"  ✓ URL: {Fore.GREEN}http://localhost:5000{Style.RESET_ALL}\n")
    threading.Thread(target=dashboard_worker, daemon=True).start()
    threading.Thread(target=lambda: socketio.run(app, host='0.0.0.0', port=5000, debug=False, use_reloader=False, log_output=False), daemon=True).start()
    time.sleep(2)

    print(f"{Fore.CYAN}[3/3] Starting capture...{Style.RESET_ALL}")
    print(f"  ✓ OpenWrt  : {Fore.YELLOW}{OPENWRT_IP}{Style.RESET_ALL}")
    print(f"  ✓ Interface: {Fore.YELLOW}{INTERFACE}{Style.RESET_ALL}\n")
    print(f"{Fore.GREEN}📡 Monitoring Evil Twin + Deauth attacks... (Ctrl+C to stop){Style.RESET_ALL}\n")

    deauth_buf  = deque(maxlen=20)
    beacon_buf  = deque(maxlen=20)
    alerts_seen = set()

    cmd    = ['ssh', f'root@{OPENWRT_IP}', 'tcpdump', '-i', INTERFACE, '-w', '-', '-s', '0', 'not', 'port', '22']
    proc   = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    reader = PcapReader(proc.stdout)

    for pkt in reader:
        if not pkt.haslayer(Dot11):
            continue

        # ---- Deauth / Disassoc detection (every packet) ----
        deauth_alert = deauth_detector.process_packet(pkt)
        if deauth_alert:
            da_payload = {
                'type'       : f"DEAUTH: {deauth_alert['type']}",
                'ssid'       : 'N/A',
                'bssid'      : deauth_alert['bssid'],
                'target'     : deauth_alert['target'],
                'frame_count': deauth_alert['frame_count'],
                'is_mobile'  : False,
                'is_deauth'  : True,
                'time'       : deauth_alert['time'],
                'severity'   : 'HIGH',
            }
            with state.lock:
                state.alerts.appendleft(da_payload)
                state.stats['alerts_count'] += 1
            socketio.emit('alert', da_payload)

        # ---- Evil Twin ML detection (beacon frames) ----
        features = extract_features(pkt, deauth_buf, beacon_buf)
        ssid  = features['ssid']
        bssid = features['bssid']
        if not ssid or not bssid:
            continue

        with state.lock:
            state.ssid_map[ssid].add(bssid)
            state.bssid_to_ssid[bssid] = ssid
            state.packet_count[(ssid, bssid)] += 1
            state.stats['total_packets'] += 1
            is_mobile_device = is_mobile(bssid)
            if is_mobile_device:
                state.stats['mobile_hotspots'] += 1

            evil_prob = 0.0
            pred = 0
            conf = 0.0
            try:
                x = np.array([features.get(k, 0) for k in feature_order], dtype=float).reshape(1, -1)
                x = scaler.transform(x)
                with torch.no_grad():
                    out         = model(torch.FloatTensor(x))
                    prob        = torch.softmax(out, dim=1)
                    evil_prob   = float(prob[0][1].item())
                    normal_prob = float(prob[0][0].item())
                    pred        = 1 if evil_prob >= normal_prob else 0
                    conf        = evil_prob if pred == 1 else normal_prob
            except Exception:
                pass

            state.net_confidence[ssid] = max(state.net_confidence.get(ssid, 0.0), evil_prob)
            conflict = len(state.ssid_map[ssid]) > 1
            if pred == 1 or conflict:
                state.stats['evil_twin_packets'] += 1
            else:
                state.stats['normal_packets'] += 1

            key = (ssid, bssid)
            if key not in alerts_seen:
                rules = []
                if conflict:        rules.append('SSID_CONFLICT')
                if is_mobile_device:rules.append('MOBILE_HOTSPOT')
                if pred == 1:       rules.append('ML_DETECTION')
                if rules:
                    alert_msg = ' + '.join(rules)
                    alert = build_alert(alert_msg, ssid, bssid, is_mobile_device)
                    state.alerts.appendleft(alert)
                    state.stats['alerts_count'] += 1
                    alerts_seen.add(key)
                    socketio.emit('alert', alert)
                    color = Fore.MAGENTA if is_mobile_device else Fore.RED
                    print(f"{color}🚨 {alert_msg}{Style.RESET_ALL}")
                    print(f"  SSID      : {ssid}")
                    print(f"  BSSID     : {bssid}")
                    print(f"  Device    : {get_device_name(bssid)}")
                    print(f"  Confidence: {conf:.3f}\n")

            state.last_update = time.time()

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}Stopped{Style.RESET_ALL}\n")
