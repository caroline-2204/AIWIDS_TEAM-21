#!/bin/bash
###############################################################################
# AI-WIDS Automated Data Collection Script
# 
# Purpose: Collects WiFi traffic from OpenWrt router for IDS training
# Network: 192.168.32.0/24 (Isolated offline LAN)
# 
# Prerequisites:
#   - OpenWrt router at 192.168.32.55 (AP mode configured)
#   - SSH access to OpenWrt (password or key-based)
#   - tcpdump installed on OpenWrt
#   - Phone A at 192.168.32.100 (normal user)
#   - Phone B at 192.168.32.105 (attack generator)
#
# Usage:
#   ./collect_all.sh
#
# Output:
#   data/raw/normal/*.pcap - Normal traffic captures
#   data/raw/test/*.pcap - Attack traffic captures
###############################################################################

# Exit on any error
set -e

###############################################################################
# CONFIGURATION
###############################################################################

# OpenWrt router IP address (where we capture packets)
OPENWRT_IP="192.168.32.55"

# Data directory (where PCAP files are saved)
DATA_DIR="../data/raw"

# Capture duration in seconds (2 minutes per capture)
DURATION=60

# SSH user for OpenWrt (usually 'root')
SSH_USER="root"

###############################################################################
# COLOR CODES FOR TERMINAL OUTPUT
###############################################################################

GREEN='\033[0;32m'   # Success messages
BLUE='\033[0;34m'    # Info messages
YELLOW='\033[1;33m'  # Warning messages
RED='\033[0;31m'     # Error messages
NC='\033[0m'         # No Color (reset)

###############################################################################
# BANNER
###############################################################################

clear
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                                                                ║"
echo "║         AI-WIDS Data Collection Pipeline                      ║"
echo "║         Network: 192.168.32.0/24 (Offline LAN)                ║"
echo "║                                                                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

###############################################################################
# PREREQUISITES CHECK
###############################################################################

echo -e "${BLUE}[*] Configuration:${NC}"
echo "    OpenWrt IP:  $OPENWRT_IP"
echo "    SSH User:    $SSH_USER"
echo "    Duration:    ${DURATION}s per capture"
echo "    Output Dir:  $DATA_DIR/"
echo ""

# Test SSH connectivity to OpenWrt
echo -e "${BLUE}[*] Testing OpenWrt connectivity...${NC}"
if ! ssh "${SSH_USER}@${OPENWRT_IP}" "echo 'SSH OK'" &> /dev/null; then
    echo -e "${RED}[!] ERROR: Cannot SSH to OpenWrt at ${OPENWRT_IP}${NC}"
    echo ""
    echo "Troubleshooting:"
    echo "  1. Check OpenWrt is powered on"
    echo "  2. Verify IP: ping ${OPENWRT_IP}"
    echo "  3. Set up SSH key: ssh-copy-id ${SSH_USER}@${OPENWRT_IP}"
    echo "  4. Or try password: ssh ${SSH_USER}@${OPENWRT_IP}"
    echo ""
    exit 1
fi
echo -e "${GREEN}[+] OpenWrt SSH connection OK${NC}"

# Check tcpdump is installed on OpenWrt
echo -e "${BLUE}[*] Checking tcpdump on OpenWrt...${NC}"
if ! ssh "${SSH_USER}@${OPENWRT_IP}" "which tcpdump" &> /dev/null; then
    echo -e "${YELLOW}[!] tcpdump not found on OpenWrt${NC}"
    echo -e "${BLUE}[*] Installing tcpdump...${NC}"
    ssh "${SSH_USER}@${OPENWRT_IP}" "opkg update && opkg install tcpdump"
    echo -e "${GREEN}[+] tcpdump installed${NC}"
else
    echo -e "${GREEN}[+] tcpdump found${NC}"
fi

echo ""

###############################################################################
# CREATE DIRECTORY STRUCTURE
###############################################################################

echo -e "${BLUE}[*] Creating directory structure...${NC}"
mkdir -p "$DATA_DIR/normal"
mkdir -p "$DATA_DIR/test"
echo -e "${GREEN}[+] Directories created${NC}"
echo ""

###############################################################################
# CAPTURE FUNCTION
# 
# This function handles the actual packet capture from OpenWrt
# 
# Parameters:
#   $1 - Output filename (e.g., "data/raw/normal/browse_001.pcap")
#   $2 - Label/description (e.g., "Normal Browsing")
#
# How it works:
#   1. SSH to OpenWrt
#   2. Run tcpdump in background on br-lan interface
#   3. Sleep for DURATION seconds
#   4. Kill tcpdump process
#   5. Stream captured packets back to this computer
#   6. Save to file
###############################################################################

capture() {
    local output="$1"
    local label="$2"

    # Print what we're capturing
    echo ""
    echo "══════════════════════════════════════════════════════════════"
    echo -e "${BLUE}[*] Capturing: $label${NC}"
    echo "══════════════════════════════════════════════════════════════"
    echo "    Output: $output"
    echo "    Duration: ${DURATION}s"
    echo ""

    # Run capture via SSH to OpenWrt
    # Explanation of command:
    #   - tcpdump -i br-lan: Capture on bridge interface (all WiFi clients)
    #   - -U: Unbuffered output (real-time streaming)
    #   - -w -: Write to stdout (dash means stdout)
    #   - not port 22: Don't capture our own SSH traffic
    #   - & : Run in background
    #   - TCP_PID=$!: Save process ID
    #   - sleep $DURATION: Wait for capture duration
    #   - kill $TCP_PID: Stop tcpdump after duration
    #   - > "$output": Save streamed packets to file

    ssh "${SSH_USER}@${OPENWRT_IP}" "
        # Start tcpdump in background
        tcpdump -i br-lan -U -w - not port 22 &
        TCP_PID=\$!

        # Wait for specified duration
        sleep $DURATION

        # Kill tcpdump process
        kill \$TCP_PID 2>/dev/null
    " > "$output" 2>/dev/null

    # Verify capture was successful
    if [ -s "$output" ]; then
        # File exists and has size > 0

        # Count packets in capture
        PKTS=$(tcpdump -r "$output" 2>/dev/null | wc -l)

        # Get file size
        SIZE=$(du -h "$output" | cut -f1)

        # Print success message
        echo -e "${GREEN}[+] Success!${NC}"
        echo "    Packets: $PKTS"
        echo "    Size: $SIZE"
        echo "    File: $output"
    else
        # Capture failed
        echo -e "${RED}[!] ERROR: Capture failed or empty${NC}"
        echo "    Check that phones are connected and generating traffic"
        return 1
    fi

    echo ""
}

###############################################################################
# PHASE 1: NORMAL TRAFFIC COLLECTION
# 
# Collect baseline normal traffic from Phone A (192.168.32.100)
# This establishes what "normal" WiFi usage looks like
###############################################################################

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                                                                ║"
echo "║         PHASE 1: Normal Traffic Collection                    ║"
echo "║         Phone A (192.168.32.100)                              ║"
echo "║                                                                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Instructions for user
echo -e "${YELLOW}Instructions for Phone A:${NC}"
echo "  1. Ensure Phone A is connected to AI-WIDS-Lab WiFi"
echo "  2. Verify IP is 192.168.32.100 (check WiFi settings)"
echo "  3. Prepare to generate normal traffic as instructed"
echo ""

# === Capture 1: Normal Web Browsing ===
read -p "Press Enter when ready for NORMAL BROWSING capture..."
echo ""
echo -e "${YELLOW}→ Phone A: Browse websites for 2 minutes${NC}"
echo "  Recommended: bbc.com, wikipedia.org, github.com"
echo "  Browse naturally: click links, scroll pages"
echo ""

capture "$DATA_DIR/normal/browse_001.pcap" "Normal Web Browsing"


###############################################################################
# COMPLETION SUMMARY
###############################################################################

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                                                                ║"
echo "║         Data Collection Complete!                             ║"
echo "║                                                                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Show captured files
echo -e "${GREEN}Normal traffic captures:${NC}"
ls -lh $DATA_DIR/normal/*.pcap 2>/dev/null | awk '{print "  ", $9, "(" $5 ")"}'


# Count total packets
echo ""
echo -e "${BLUE}[*] Summary:${NC}"
TOTAL_NORMAL=0
TOTAL_ATTACK=0

for f in $DATA_DIR/normal/*.pcap; do
    COUNT=$(tcpdump -r "$f" 2>/dev/null | wc -l)
    TOTAL_NORMAL=$((TOTAL_NORMAL + COUNT))
done


echo "    Normal packets: $TOTAL_NORMAL"
echo "    Total packets: $((TOTAL_NORMAL))"

# Next steps
echo ""
echo -e "${BLUE}[*] Next steps:${NC}"
echo "    1. Feature extraction:"
echo "       python src/extract_features.py"
echo ""
echo "    2. Model training:"
echo "       python src/train_model.py"
echo ""
echo "    3. Live detection:"
echo "       python src/live_detection.py"
echo ""
