#!/usr/bin/env python3
"""
AI-WIDS Model Training Script

Purpose:
    Train a deep neural network classifier to detect WiFi attacks using PyTorch.
    Implements binary classification: normal vs. attack traffic.

Input:
    - data/processed/features.csv (extracted features with labels)

Output:
    - models/wireless_ids.pt (trained PyTorch model)
    - models/preprocessors.joblib (scaler and encoders)
    - logs/training.log (training metrics)

Model Architecture:
    Input Layer (24 features)
    → Dense(128) + ReLU + BatchNorm + Dropout
    → Dense(64) + ReLU + BatchNorm + Dropout
    → Output(2 classes: normal/attack)

Training Features:
    - Early stopping (patience=5)
    - Learning rate: 0.001 (Adam optimizer)
    - Batch size: 256
    - Max epochs: 30

Usage:
    python src/train_model.py \
        --data ../data/processed/features.csv \
        --output ../models/wireless_ids.pt \
        --epochs 30
"""

import argparse
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import joblib

# Check PyTorch installation
try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    from torch.utils.data import DataLoader, TensorDataset
except ImportError:
    print("[!] ERROR: PyTorch not installed")
    print("    Install with: pip install torch")
    sys.exit(1)

# Check scikit-learn installation
try:
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler, LabelEncoder
    from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix)
except ImportError:
    print("[!] ERROR: scikit-learn not installed")
    print("    Install with: pip install scikit-learn")
    sys.exit(1)

###############################################################################
# NEURAL NETWORK MODEL DEFINITION
###############################################################################

class WirelessIDS(nn.Module):
    """
    Deep Neural Network for Wireless Intrusion Detection.

    Architecture:
        - Input layer: variable size (number of features)
        - Hidden layers: configurable (default: [128, 64])
        - Each hidden layer has: Linear → ReLU → BatchNorm → Dropout
        - Output layer: 2 units (binary classification)

    Args:
        input_dim (int): Number of input features
        hidden_dims (list): List of hidden layer sizes
        dropout (float): Dropout rate for regularization
    """

    def __init__(self, input_dim, hidden_dims=[128, 64], dropout=0.3):
        super(WirelessIDS, self).__init__()

        # Build network layers dynamically
        layers = []
        prev_dim = input_dim

        # Create hidden layers
        for hidden_dim in hidden_dims:
            # Linear transformation
            layers.append(nn.Linear(prev_dim, hidden_dim))

            # ReLU activation
            layers.append(nn.ReLU())

            # Batch normalization (helps training stability)
            layers.append(nn.BatchNorm1d(hidden_dim))

            # Dropout (prevents overfitting)
            layers.append(nn.Dropout(dropout))

            prev_dim = hidden_dim

        # Output layer (2 classes: normal vs attack)
        layers.append(nn.Linear(prev_dim, 2))

        # Combine all layers into sequential model
        self.network = nn.Sequential(*layers)

    def forward(self, x):
        """
        Forward pass through the network.

        Args:
            x (torch.Tensor): Input features [batch_size, input_dim]

        Returns:
            torch.Tensor: Raw logits [batch_size, 2]
        """
        return self.network(x)

###############################################################################
# DATA PREPARATION FUNCTION
###############################################################################

def prepare_data(csv_path):
    """
    Load and preprocess data for model training.

    Steps:
        1. Load CSV file
        2. Separate features and labels
        3. Encode categorical features
        4. Encode labels (normal=0, attack=1)
        5. Split into train/test sets (80/20)
        6. Standardize features (zero mean, unit variance)

    Args:
        csv_path (str): Path to features CSV file

    Returns:
        tuple: (X_train, X_test, y_train, y_test, scaler, label_encoder, feature_encoders)
    """

    print("[*] Loading data...")

    # Load CSV into pandas DataFrame
    df = pd.read_csv(csv_path)

    print(f"[+] Loaded {len(df):,} samples")
    print(f"[+] Features: {len(df.columns) - 1}")  # -1 for label column

    ###########################################################################
    # SEPARATE FEATURES AND LABELS
    ###########################################################################

    # X = all columns except 'label'
    X = df.drop('label', axis=1)

    # y = 'label' column
    y = df['label']

    ###########################################################################
    # ENCODE CATEGORICAL FEATURES
    # 
    # Some features like 'src_ip', 'dst_ip' are strings and need encoding
    ###########################################################################

    # Find categorical columns (object type)
    categorical_cols = X.select_dtypes(include=['object']).columns

    # Create encoder for each categorical column
    feature_encoders = {}

    for col in categorical_cols:
        le = LabelEncoder()
        # Convert to string and encode
        X[col] = le.fit_transform(X[col].astype(str))
        # Save encoder for later use (inference)
        feature_encoders[col] = le

    if categorical_cols.any():
        print(f"[+] Encoded {len(categorical_cols)} categorical features")

    ###########################################################################
    # HANDLE MISSING VALUES
    ###########################################################################

    # Fill NaN with 0 (shouldn't have any, but safety check)
    X = X.fillna(0)

    ###########################################################################
    # ENCODE LABELS
    ###########################################################################

    # Encode labels: normal=0, attack=1
    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)

    print(f"[+] Classes: {label_encoder.classes_}")

    # Print class distribution
    print("[+] Distribution:")
    for label_idx, label_name in enumerate(label_encoder.classes_):
        count = (y_encoded == label_idx).sum()
        pct = 100 * count / len(y_encoded)
        print(f"      {label_name:10s}: {count:6,} ({pct:5.1f}%)")

    ###########################################################################
    # TRAIN/TEST SPLIT
    ###########################################################################

    # Split 80% train, 20% test
    # stratify=y_encoded ensures balanced split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_encoded,
        test_size=0.2,
        random_state=42,
        stratify=y_encoded
    )

    print(f"[+] Train set: {len(X_train):,} samples")
    print(f"[+] Test set:  {len(X_test):,} samples")

    ###########################################################################
    # FEATURE SCALING
    # 
    # Standardize features to have mean=0, std=1
    # This helps neural network training converge faster
    ###########################################################################

    scaler = StandardScaler()

    # Fit scaler on training data only (prevent data leakage)
    X_train_scaled = scaler.fit_transform(X_train)

    # Transform test data using same scaler
    X_test_scaled = scaler.transform(X_test)

    print(f"[+] Features scaled (mean=0, std=1)")

    return (X_train_scaled, X_test_scaled, y_train, y_test, scaler, label_encoder, feature_encoders)

###############################################################################
# MODEL TRAINING FUNCTION
###############################################################################

def train_model(X_train, y_train, X_test, y_test, epochs=30, batch_size=256):
    """
    Train the PyTorch neural network model.

    Args:
        X_train (np.ndarray): Training features
        y_train (np.ndarray): Training labels
        X_test (np.ndarray): Test features
        y_test (np.ndarray): Test labels
        epochs (int): Maximum training epochs
        batch_size (int): Mini-batch size

    Returns:
        tuple: (trained_model, best_accuracy)
    """

    ###########################################################################
    # SETUP DEVICE (CPU or GPU)
    ###########################################################################

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"[*] Using device: {device}")

    if device.type == 'cuda':
        print(f"    GPU: {torch.cuda.get_device_name(0)}")

    ###########################################################################
    # CONVERT TO PYTORCH TENSORS
    ###########################################################################

    # Convert numpy arrays to PyTorch tensors
    X_train_tensor = torch.FloatTensor(X_train)
    y_train_tensor = torch.LongTensor(y_train)
    X_test_tensor = torch.FloatTensor(X_test)
    y_test_tensor = torch.LongTensor(y_test)

    ###########################################################################
    # CREATE DATALOADERS
    # 
    # DataLoader handles batching and shuffling automatically
    ###########################################################################

    train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
    test_dataset = TensorDataset(X_test_tensor, y_test_tensor)

    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True  # Shuffle training data each epoch
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False  # Don't shuffle test data
    )

    ###########################################################################
    # INITIALIZE MODEL
    ###########################################################################

    input_dim = X_train.shape[1]

    model = WirelessIDS(
        input_dim=input_dim,
        hidden_dims=[128, 64],
        dropout=0.3
    ).to(device)

    print(f"[*] Model architecture: {input_dim} → 128 → 64 → 2")

    # Print total parameters
    total_params = sum(p.numel() for p in model.parameters())
    print(f"[*] Total parameters: {total_params:,}")

    ###########################################################################
    # LOSS FUNCTION AND OPTIMIZER
    ###########################################################################

    # CrossEntropyLoss for multi-class classification
    criterion = nn.CrossEntropyLoss()

    # Adam optimizer (adaptive learning rate)
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    ###########################################################################
    # TRAINING LOOP
    ###########################################################################

    print(f"[*] Training for {epochs} epochs...")
    print()

    # Track best model for early stopping
    best_acc = 0.0
    best_model_state = None
    patience = 5
    patience_counter = 0

    for epoch in range(epochs):

        #######################################################################
        # TRAINING PHASE
        #######################################################################

        model.train()  # Set model to training mode
        train_loss = 0.0

        for batch_X, batch_y in train_loader:
            # Move batch to device (GPU or CPU)
            batch_X = batch_X.to(device)
            batch_y = batch_y.to(device)

            # Zero gradients from previous step
            optimizer.zero_grad()

            # Forward pass
            outputs = model(batch_X)

            # Compute loss
            loss = criterion(outputs, batch_y)

            # Backward pass (compute gradients)
            loss.backward()

            # Update weights
            optimizer.step()

            # Accumulate loss
            train_loss += loss.item()

        # Average training loss
        train_loss /= len(train_loader)

        #######################################################################
        # VALIDATION PHASE
        #######################################################################

        model.eval()  # Set model to evaluation mode
        test_loss = 0.0
        correct = 0
        total = 0

        # No gradient computation for validation
        with torch.no_grad():
            for batch_X, batch_y in test_loader:
                batch_X = batch_X.to(device)
                batch_y = batch_y.to(device)

                # Forward pass
                outputs = model(batch_X)

                # Compute loss
                loss = criterion(outputs, batch_y)
                test_loss += loss.item()

                # Get predictions
                _, predicted = torch.max(outputs.data, 1)

                # Count correct predictions
                total += batch_y.size(0)
                correct += (predicted == batch_y).sum().item()

        # Average test loss and accuracy
        test_loss /= len(test_loader)
        test_acc = 100 * correct / total

        # Print epoch results
        print(f"Epoch [{epoch+1:2d}/{epochs}]  "
              f"Train Loss: {train_loss:.4f}  "
              f"Test Loss: {test_loss:.4f}  "
              f"Test Acc: {test_acc:.2f}%")

        #######################################################################
        # EARLY STOPPING
        # 
        # Save best model and stop if no improvement for 'patience' epochs
        #######################################################################

        if test_acc > best_acc:
            # New best accuracy
            best_acc = test_acc
            best_model_state = model.state_dict().copy()
            patience_counter = 0
        else:
            # No improvement
            patience_counter += 1

            if patience_counter >= patience:
                print()
                print(f"[*] Early stopping at epoch {epoch+1}")
                print(f"    No improvement for {patience} epochs")
                break

    print()

    # Load best model
    model.load_state_dict(best_model_state)

    return model, best_acc

###############################################################################
# MODEL EVALUATION FUNCTION
###############################################################################

def evaluate_model(model, X_test, y_test, label_encoder):
    """
    Evaluate trained model on test set.

    Args:
        model: Trained PyTorch model
        X_test (np.ndarray): Test features
        y_test (np.ndarray): Test labels
        label_encoder: Label encoder for class names

    Returns:
        dict: Evaluation metrics
    """

    device = next(model.parameters()).device
    model.eval()

    # Convert to tensor
    X_test_tensor = torch.FloatTensor(X_test).to(device)

    # Get predictions
    with torch.no_grad():
        outputs = model(X_test_tensor)
        _, predictions = torch.max(outputs, 1)

    predictions_np = predictions.cpu().numpy()

    ###########################################################################
    # COMPUTE METRICS
    ###########################################################################

    acc = accuracy_score(y_test, predictions_np)

    # For binary classification
    if len(label_encoder.classes_) == 2:
        # Assuming attack = 1, normal = 0
        precision = precision_score(y_test, predictions_np, pos_label=1)
        recall = recall_score(y_test, predictions_np, pos_label=1)
        f1 = f1_score(y_test, predictions_np, pos_label=1)
    else:
        precision = precision_score(y_test, predictions_np, average='weighted')
        recall = recall_score(y_test, predictions_np, average='weighted')
        f1 = f1_score(y_test, predictions_np, average='weighted')

    ###########################################################################
    # PRINT RESULTS
    ###########################################################################

    print("═" * 70)
    print("  Evaluation Results")
    print("═" * 70)
    print(f"Accuracy:  {acc:.4f} ({100*acc:.2f}%)")
    print(f"Precision: {precision:.4f}")
    print(f"Recall:    {recall:.4f}")
    print(f"F1-Score:  {f1:.4f}")
    print()

    print("Classification Report:")
    print(classification_report(
        y_test, predictions_np,
        target_names=label_encoder.classes_
    ))

    print("Confusion Matrix:")
    cm = confusion_matrix(y_test, predictions_np)
    print(cm)
    print()

    # Interpret confusion matrix
    if len(label_encoder.classes_) == 2:
        tn, fp, fn, tp = cm.ravel()
        fpr = fp / (fp + tn) if (fp + tn) > 0 else 0
        fnr = fn / (fn + tp) if (fn + tp) > 0 else 0

        print("Detailed Metrics:")
        print(f"  True Positives:  {tp:5d} (attacks correctly detected)")
        print(f"  True Negatives:  {tn:5d} (normal correctly identified)")
        print(f"  False Positives: {fp:5d} (normal flagged as attack)")
        print(f"  False Negatives: {fn:5d} (attacks missed)")
        print()
        print(f"  False Positive Rate: {fpr:.4f} ({100*fpr:.2f}%)")
        print(f"  False Negative Rate: {fnr:.4f} ({100*fnr:.2f}%)")
        print()

    return {
        'accuracy': acc,
        'precision': precision,
        'recall': recall,
        'f1': f1
    }

###############################################################################
# MAIN FUNCTION
###############################################################################

def main():
    """
    Main training pipeline.

    Steps:
        1. Parse arguments
        2. Load and preprocess data
        3. Train model
        4. Evaluate model
        5. Save model and preprocessors
    """

    # Parse command line arguments
    parser = argparse.ArgumentParser(
        description='AI-WIDS Model Training Pipeline'
    )

    parser.add_argument(
        '--data',
        type=str,
        default='../data/processed/features.csv',
        help='Input CSV file with features'
    )

    parser.add_argument(
        '--output',
        type=str,
        default='../models/wireless_ids.pt',
        help='Output model file'
    )

    parser.add_argument(
        '--epochs',
        type=int,
        default=30,
        help='Maximum training epochs'
    )

    parser.add_argument(
        '--batch-size',
        type=int,
        default=256,
        help='Training batch size'
    )

    args = parser.parse_args()

    # Print banner
    print("╔════════════════════════════════════════════════════════════════╗")
    print("║         AI-WIDS Model Training Pipeline                       ║")
    print("╚════════════════════════════════════════════════════════════════╝")
    print()

    ###########################################################################
    # STEP 1: PREPARE DATA
    ###########################################################################

    (X_train, X_test, y_train, y_test,
     scaler, label_encoder, feature_encoders) = prepare_data(args.data)

    print()

    ###########################################################################
    # STEP 2: TRAIN MODEL
    ###########################################################################

    model, best_acc = train_model(
        X_train, y_train, X_test, y_test,
        epochs=args.epochs,
        batch_size=args.batch_size
    )

    ###########################################################################
    # STEP 3: EVALUATE MODEL
    ###########################################################################

    metrics = evaluate_model(model, X_test, y_test, label_encoder)

    ###########################################################################
    # STEP 4: SAVE MODEL AND PREPROCESSORS
    ###########################################################################

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Save model with configuration
    torch.save({
        'model_state_dict': model.state_dict(),
        'model_config': {
            'input_dim': X_train.shape[1],
            'hidden_dims': [128, 64],
            'dropout': 0.3
        },
        'metrics': metrics
    }, output_path)

    # Save preprocessors
    preprocessor_path = output_path.parent / 'preprocessors.joblib'
    joblib.dump({
        'scaler': scaler,
        'label_encoder': label_encoder,
        'feature_encoders': feature_encoders
    }, preprocessor_path)

    print("═" * 70)
    print("  Training Complete")
    print("═" * 70)
    print(f"[+] Model saved: {output_path}")
    print(f"[+] Preprocessors saved: {preprocessor_path}")
    print(f"[+] Best accuracy: {best_acc:.2f}%")
    print()

    # Next steps
    print("Next steps:")
    print("  1. Live detection:")
    print("     python src/live_detection.py")
    print()

###############################################################################
# ENTRY POINT
###############################################################################

if __name__ == "__main__":
    main()
