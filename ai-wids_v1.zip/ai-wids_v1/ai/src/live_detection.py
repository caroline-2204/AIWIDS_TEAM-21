#!/usr/bin/env python3
"""
AI-WIDS Live Detection System

Purpose:
    Real-time wireless attack detection by streaming traffic from OpenWrt
    and classifying it with trained neural network model.

Prerequisites:
    - Trained model: models/wireless_ids.pt
    - Preprocessors: models/preprocessors.joblib
    - OpenWrt router accessible via SSH
    - tcpdump running on OpenWrt

Features:
    - Real-time packet capture and analysis
    - Color-coded detection output
    - Attack type identification (DoS, MITM, Scan)
    - Session statistics and logging

Usage:
    # Basic usage
    python src/live_detection.py

    # Custom OpenWrt IP
    python src/live_detection.py --openwrt-ip 192.168.32.55

    # With logging
    python src/live_detection.py --log logs/detection.log

Output:
    Terminal display:
        [OK   ] 192.168.32.100 → 8.8.8.8 (Normal: 0.98)
        [ALERT!] 192.168.32.105 → 192.168.32.10:8000 (ATTACK: 0.95)
        [DOS!] 192.168.32.105 SYN flood: 120 pkts/sec
"""

import sys
import argparse
import subprocess
from pathlib import Path
from collections import defaultdict, deque
from datetime import datetime
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")
import threading



# Check dependencies
try:
    import torch
    import torch.nn as nn
except ImportError:
    print("[!] ERROR: PyTorch not installed")
    print("    Install with: pip install torch")
    sys.exit(1)

try:
    import joblib
except ImportError:
    print("[!] ERROR: joblib not installed")
    print("    Install with: pip install joblib")
    sys.exit(1)

try:
    from scapy.all import sniff, IP, TCP, UDP, ARP, DNS, DHCP
except ImportError:
    print("[!] ERROR: scapy not installed")
    print("    Install with: pip install scapy")
    sys.exit(1)

###############################################################################
# COLOR CODES FOR TERMINAL OUTPUT
###############################################################################

class Colors:
    """ANSI color codes for terminal output"""
    GREEN = '\033[0;32m'      # Normal traffic
    YELLOW = '\033[1;33m'     # Warnings/uncertain
    RED = '\033[0;31m'        # Attacks
    MAGENTA = '\033[95m'      # MITM attacks
    BLUE = '\033[0;34m'       # Info messages
    CYAN = '\033[0;36m'       # Headers
    NC = '\033[0m'            # Reset (No Color)
    BOLD = '\033[1m'          # Bold text

###############################################################################
# NEURAL NETWORK MODEL (same as training)
###############################################################################

class WirelessIDS(nn.Module):
    """
    Deep Neural Network for Wireless Intrusion Detection.
    Same architecture as training script.
    """

    def __init__(self, input_dim, hidden_dims=[128, 64], dropout=0.3):
        super(WirelessIDS, self).__init__()

        layers = []
        prev_dim = input_dim

        for hidden_dim in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, hidden_dim),
                nn.ReLU(),
                nn.BatchNorm1d(hidden_dim),
                nn.Dropout(dropout)
            ])
            prev_dim = hidden_dim

        layers.append(nn.Linear(prev_dim, 2))
        self.network = nn.Sequential(*layers)

    def forward(self, x):
        return self.network(x)

###############################################################################
# GLOBAL STATE VARIABLES
###############################################################################

# Model and preprocessors (loaded at startup)
model = None
preprocessors = None
device = None

# Traffic tracking dictionaries
SYN_COUNTER = defaultdict(int)      # Track SYN packets per IP
ARP_RATE = defaultdict(int)         # Track ARP packets per IP
DNS_QUERIES = defaultdict(int)      # Track DNS queries per IP
CONNECTION_RATE = defaultdict(int)  # Track connection attempts per IP

# Recent packet history (for statistics)
packet_history = deque(maxlen=1000)

# Detection statistics
detection_stats = {
    'total': 0,
    'normal': 0,
    'attack': 0,
    'dos': 0,
    'mitm': 0,
    'scan': 0
}

# Logging
log_file = None

###############################################################################
# MODEL LOADING FUNCTION
###############################################################################

def load_model(model_path, preprocessor_path):
    """
    Load trained model and preprocessors from disk.

    Args:
        model_path (str): Path to saved PyTorch model
        preprocessor_path (str): Path to saved preprocessors

    Returns:
        None (sets global variables)
    """
    global model, preprocessors, device

    # Determine device (GPU if available, else CPU)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    ###########################################################################
    # LOAD MODEL
    ###########################################################################

    print(f"[*] Loading model from: {model_path}")

    try:
        # Load checkpoint
        checkpoint = torch.load(model_path, map_location=device)

        # Get model configuration
        config = checkpoint['model_config']

        # Create model instance
        model = WirelessIDS(
            input_dim=config['input_dim'],
            hidden_dims=config['hidden_dims'],
            dropout=config['dropout']
        ).to(device)

        # Load trained weights
        model.load_state_dict(checkpoint['model_state_dict'])

        # Set to evaluation mode
        model.eval()

        print(f"{Colors.GREEN}[+] Model loaded successfully{Colors.NC}")

        # Print model info
        if 'metrics' in checkpoint:
            metrics = checkpoint['metrics']
            print(f"    Accuracy: {metrics['accuracy']:.4f}")
            print(f"    F1-Score: {metrics['f1']:.4f}")

    except FileNotFoundError:
        print(f"{Colors.RED}[!] ERROR: Model file not found: {model_path}{Colors.NC}")
        print("    Train model first: python src/train_model.py")
        sys.exit(1)
    except Exception as e:
        print(f"{Colors.RED}[!] ERROR loading model: {e}{Colors.NC}")
        sys.exit(1)

    ###########################################################################
    # LOAD PREPROCESSORS
    ###########################################################################

    print(f"[*] Loading preprocessors from: {preprocessor_path}")

    try:
        preprocessors = joblib.load(preprocessor_path)
        print(f"{Colors.GREEN}[+] Preprocessors loaded successfully{Colors.NC}")

    except FileNotFoundError:
        print(f"{Colors.RED}[!] ERROR: Preprocessors not found: {preprocessor_path}{Colors.NC}")
        print("    Train model first: python src/train_model.py")
        sys.exit(1)
    except Exception as e:
        print(f"{Colors.RED}[!] ERROR loading preprocessors: {e}{Colors.NC}")
        sys.exit(1)

    print(f"{Colors.BLUE}[*] Using device: {device}{Colors.NC}")

###############################################################################
# FEATURE EXTRACTION (same as training)
###############################################################################

def extract_features(pkt):
    """
    Extract features from a live packet.
    Returns features and display IPs for human-readable output.
    """
    features = {}

    # --- Basic ---
    features['frame_len'] = len(pkt)
    features['timestamp'] = float(pkt.time) if hasattr(pkt, 'time') else 0

    # --- IP layer ---
    if pkt.haslayer(IP):
        features['has_ip'] = 1
        features['src_ip'] = pkt[IP].src
        features['dst_ip'] = pkt[IP].dst
        features['ip_proto'] = pkt[IP].proto
        features['ttl'] = pkt[IP].ttl
        features['display_src_ip'] = pkt[IP].src
        features['display_dst_ip'] = pkt[IP].dst
    else:
        features['has_ip'] = 0
        features['src_ip'] = "0.0.0.0"
        features['dst_ip'] = "0.0.0.0"
        features['ip_proto'] = 0
        features['ttl'] = 0
        features['display_src_ip'] = pkt[ARP].psrc if pkt.haslayer(ARP) else "N/A"
        features['display_dst_ip'] = pkt[ARP].pdst if pkt.haslayer(ARP) else "N/A"

    # --- TCP layer ---
    if pkt.haslayer(TCP):
        features['has_tcp'] = 1
        features['src_port'] = pkt[TCP].sport
        features['dst_port'] = pkt[TCP].dport
        features['tcp_flags'] = int(pkt[TCP].flags)
        features['tcp_window'] = pkt[TCP].window
        features['is_syn'] = int(pkt[TCP].flags == 'S')
        features['is_ack'] = int(pkt[TCP].flags == 'A')
        features['is_rst'] = int(pkt[TCP].flags == 'R')
    else:
        features['has_tcp'] = 0
        features['src_port'] = 0
        features['dst_port'] = 0
        features['tcp_flags'] = 0
        features['tcp_window'] = 0
        features['is_syn'] = 0
        features['is_ack'] = 0
        features['is_rst'] = 0

    # --- UDP layer ---
    features['has_udp'] = int(pkt.haslayer(UDP))
    features['udp_len'] = pkt[UDP].len if pkt.haslayer(UDP) else 0

    # --- ARP layer ---
    features['has_arp'] = int(pkt.haslayer(ARP))
    features['arp_op'] = pkt[ARP].op if pkt.haslayer(ARP) else 0

    # --- DNS layer ---
    features['has_dns'] = int(pkt.haslayer(DNS))
    features['dns_qr'] = pkt[DNS].qr if pkt.haslayer(DNS) else 0

    # --- DHCP layer ---
    features['has_dhcp'] = int(pkt.haslayer(DHCP))

    # --- Rate tracking ---
    if features['is_syn'] and features['display_src_ip'] != "N/A":
        SYN_COUNTER[features['display_src_ip']] += 1
        features['syn_rate'] = SYN_COUNTER[features['display_src_ip']]
    else:
        features['syn_rate'] = 0

    if features['has_arp'] and features['display_src_ip'] != "N/A":
        ARP_RATE[features['display_src_ip']] += 1
        features['arp_rate'] = ARP_RATE[features['display_src_ip']]
    else:
        features['arp_rate'] = 0

    if features['has_dns'] and features['display_src_ip'] != "N/A":
        DNS_QUERIES[features['display_src_ip']] += 1
        features['dns_rate'] = DNS_QUERIES[features['display_src_ip']]
    else:
        features['dns_rate'] = 0

    return features

###############################################################################
# PREDICTION FUNCTION
###############################################################################

def predict(features):
    """
    Run ML prediction on extracted features.

    Args:
        features (dict): Dictionary of packet features

    Returns:
        tuple: (predicted_label, confidence)
            predicted_label (str): 'normal' or 'attack'
            confidence (float): Prediction confidence (0-1)
    """

    ###########################################################################
    # ENCODE CATEGORICAL FEATURES
    ###########################################################################

    feature_encoders = preprocessors['feature_encoders']

    for col, encoder in feature_encoders.items():
        if col in features:
            try:
                # Encode feature using saved encoder
                features[col] = encoder.transform([str(features[col])])[0]
            except:
                # Unknown value, use default
                features[col] = 0

    ###########################################################################
    # CREATE FEATURE VECTOR
    ###########################################################################

    # Convert dict to numpy array (must match training order)
    feature_values = []
    for key in sorted(features.keys()):
        if key != 'label':  # Skip label if present
            feature_values.append(features[key])

    # feature_vec = np.array([feature_values])
    feature_df = pd.DataFrame([features])

    ###########################################################################
    # STANDARDIZE FEATURES
    ###########################################################################

    scaler = preprocessors['scaler']
    # feature_scaled = scaler.transform(feature_vec)

    # Ensure column order matches training
    feature_df = feature_df[scaler.feature_names_in_]
    feature_scaled = scaler.transform(feature_df)

    ###########################################################################
    # RUN MODEL PREDICTION
    ###########################################################################

    with torch.no_grad():
        # Convert to tensor
        X_tensor = torch.FloatTensor(feature_scaled).to(device)

        # Forward pass
        output = model(X_tensor)

        # Get probabilities (softmax)
        probs = torch.softmax(output, dim=1)

        # Get prediction
        pred_idx = torch.argmax(output, dim=1).item()
        confidence = probs[0][pred_idx].item()

    # Decode prediction
    # label_encoder = preprocessors['label_encoder']
    # pred_label = label_encoder.inverse_transform([pred_idx])[0]
    pred_label = "normal" if pred_idx == 0 else "attack"
    return pred_label, confidence

###############################################################################
# DETECTION OUTPUT FUNCTION
###############################################################################
# Keep track of last printed packet per src-dst-attack_type
last_printed = {}

def print_detection(features, pred_label, confidence):
    """
    Human-readable detection output with repetition collapse.
    """
    src_ip = features['display_src_ip']
    dst_ip = features['display_dst_ip']
    src_port = features['src_port']
    dst_port = features['dst_port']
    timestamp = datetime.now().strftime('%H:%M:%S')

    if src_ip == "N/A" and dst_ip == "N/A":
        return

    # Connection string
    if features['has_arp']:
        conn = f"ARP: {src_ip} -> {dst_ip}"
    elif src_port > 0:
        conn = f"{src_ip}:{src_port} -> {dst_ip}:{dst_port}"
    else:
        conn = f"{src_ip} -> {dst_ip}"

    # Determine attack type
    attack_type = "NORMAL"
    label = "OK"
    color = Colors.GREEN

    if features['syn_rate'] > 50:
        attack_type = "DoS (SYN Flood)"
        label = "DOS!"
        color = Colors.BLUE
    elif features['arp_rate'] > 10:
        attack_type = "MITM (ARP Spoof)"
        label = "MITM!"
        color = Colors.MAGENTA
    elif features['tcp_flags'] == 2 and 0 < dst_port < 1024:
        attack_type = "Port Scan"
        label = "SCAN!"
        color = Colors.CYAN
    elif features['dns_rate'] > 30:
        attack_type = "DNS Flood"
        label = "ATTACK"
        color = Colors.RED
    elif pred_label == "attack" and confidence > 0.98:
        attack_type = "Unknown Attack"
        label = "ATTACK"
        color = Colors.RED
    elif pred_label == "normal" and confidence < 0.95:
        label = "WARN"
        color = Colors.YELLOW
        attack_type = "Uncertain"

    # Use last_printed dict to collapse repeats
    key = (conn, attack_type)
    count = 1
    if key in last_printed:
        last_printed[key]['count'] += 1
        last_printed[key]['timestamp'] = timestamp
        last_printed[key]['confidence'] = confidence
        return  # don't print again immediately
    else:
        last_printed[key] = {'count': 1, 'timestamp': timestamp, 'confidence': confidence}

    # Print
    print(
        f"{color}[{label:^7}]{Colors.NC} "
        f"{timestamp} | "
        f"{conn:<45} | "
        f"{attack_type:<18} | "
        f"Conf: {confidence:.2f}"
    )

    # Logging
    if log_file:
        log_file.write(
            f"{timestamp} [{label}] {conn} {attack_type} {confidence:.2f}\n"
        )
        log_file.flush()

    # Update stats
    detection_stats['total'] += 1
    if attack_type == "NORMAL":
        detection_stats['normal'] += 1
    else:
        detection_stats['attack'] += 1
        if "DoS" in attack_type:
            detection_stats['dos'] += 1
        elif "MITM" in attack_type:
            detection_stats['mitm'] += 1
        elif "Scan" in attack_type:
            detection_stats['scan'] += 1







###############################################################################
# PACKET HANDLER FUNCTION
###############################################################################

def packet_handler(pkt):
    """
    Handle each captured packet.
    Called by Scapy for every packet received.

    Args:
        pkt: Scapy packet object

    Returns:
        None
    """
    if not pkt.haslayer(IP) and not pkt.haslayer(ARP):
        return

    try:
        # Extract features
        features = extract_features(pkt)

        # Run prediction
        pred_label, confidence = predict(features)

        # Print detection result
        print_detection(features, pred_label, confidence)

        # Store in history
        packet_history.append({
            'timestamp': datetime.now(),
            'features': features,
            'prediction': pred_label,
            'confidence': confidence
        })

    except Exception as e:
        # Skip packets that cause errors
        # pass
        print(e)

###############################################################################
# MAIN FUNCTION
###############################################################################

def main():
    """
    Main execution function.

    Workflow:
        1. Parse arguments
        2. Load model and preprocessors
        3. Start SSH stream from OpenWrt
        4. Process packets in real-time
        5. Display statistics on exit
    """

    global log_file

    # Parse command line arguments
    parser = argparse.ArgumentParser(
        description='AI-WIDS Live Detection System',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Basic usage
    python src/live_detection.py

    # Custom OpenWrt IP
    python src/live_detection.py --openwrt-ip 192.168.32.55

    # With logging
    python src/live_detection.py --log logs/detection.log
        """
    )

    parser.add_argument(
        '--model',
        type=str,
        default='../models/wireless_ids.pt',
        help='Path to trained model file'
    )

    parser.add_argument(
        '--preprocessors',
        type=str,
        default='../models/preprocessors.joblib',
        help='Path to preprocessors file'
    )

    parser.add_argument(
        '--openwrt-ip',
        type=str,
        default='192.168.32.55',
        help='OpenWrt router IP address'
    )

    parser.add_argument(
        '--log',
        type=str,
        default=None,
        help='Log file path (optional)'
    )

    args = parser.parse_args()


    ###########################################################################
    # BANNER
    ###########################################################################

    print("╔════════════════════════════════════════════════════════════════╗")
    print("║                                                                ║")
    print("║         AI-WIDS Live Detection System                         ║")
    print("║         Real-time Wireless Attack Detection                   ║")
    print("║                                                                ║")
    print("╚════════════════════════════════════════════════════════════════╝")
    print()

    ###########################################################################
    # LOAD MODEL
    ###########################################################################

    load_model(args.model, args.preprocessors)
    print()

    ###########################################################################
    # SETUP LOGGING
    ###########################################################################

    if args.log:
        log_path = Path(args.log)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_file = open(log_path, 'a')
        print(f"{Colors.GREEN}[+] Logging to: {log_path}{Colors.NC}")
        print()

    def reset_counters():
        SYN_COUNTER.clear()
        ARP_RATE.clear()
        DNS_QUERIES.clear()
        threading.Timer(5.0, reset_counters).start()
    # Call once at program start
    reset_counters()

    ###########################################################################
    # START LIVE CAPTURE
    ###########################################################################

    print(f"{Colors.BLUE}[*] Starting live capture from OpenWrt ({args.openwrt_ip})...{Colors.NC}")
    print(f"{Colors.YELLOW}[*] Press Ctrl+C to stop{Colors.NC}")
    print()

    # Print legend
    print("Detection codes:")
    print(f"  {Colors.GREEN}[OK   ]{Colors.NC} - Normal traffic (high confidence)")
    print(f"  {Colors.YELLOW}[WARN ]{Colors.NC} - Uncertain classification")
    print(f"  {Colors.RED}[ALERT!]{Colors.NC} - Generic attack detected")
    print(f"  {Colors.RED}[DOS!]{Colors.NC} - DoS attack (SYN flood)")
    print(f"  {Colors.MAGENTA}[MITM!]{Colors.NC} - MITM attack (ARP spoof)")
    print(f"  {Colors.RED}[SCAN!]{Colors.NC} - Port scanning attack")
    print()
    print("═" * 70)
    print()

    ###########################################################################
    # STREAM PACKETS FROM OPENWRT VIA SSH
    ###########################################################################

    # Start SSH process that streams tcpdump output
    ssh_cmd = [
        'ssh',
        f'root@{args.openwrt_ip}',
        'tcpdump -i br-lan -U -w - not port 22'
    ]

    try:
        proc = subprocess.Popen(
            ssh_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL
        )

        # Sniff from SSH stream
        sniff(offline=proc.stdout, prn=packet_handler, store=0)

    except KeyboardInterrupt:
        ###################################################################
        # USER INTERRUPTED (Ctrl+C)
        ###################################################################

        print()
        print(f"{Colors.YELLOW}[*] Stopping...{Colors.NC}")

        # Terminate SSH process
        proc.terminate()

        # Close log file
        if log_file:
            log_file.close()

        ###################################################################
        # PRINT SESSION SUMMARY
        ###################################################################

        print()
        print("═" * 70)
        print("  Session Summary")
        print("═" * 70)

        total = detection_stats['total']
        normal = detection_stats['normal']
        attack = detection_stats['attack']

        if total > 0:
            print(f"Total packets analyzed: {total:,}")
            print()
            print(f"Normal:  {normal:6,} ({100*normal/total:5.1f}%)")
            print(f"Attacks: {attack:6,} ({100*attack/total:5.1f}%)")

            if detection_stats['dos'] > 0:
                print(f"  - DoS:  {detection_stats['dos']:6,}")
            if detection_stats['mitm'] > 0:
                print(f"  - MITM: {detection_stats['mitm']:6,}")
            if detection_stats['scan'] > 0:
                print(f"  - Scan: {detection_stats['scan']:6,}")
        else:
            print("No packets analyzed")

        print()

    except Exception as e:
        print(f"{Colors.RED}[!] ERROR: {e}{Colors.NC}")
        sys.exit(1)

###############################################################################
# ENTRY POINT
###############################################################################

if __name__ == "__main__":
    main()
