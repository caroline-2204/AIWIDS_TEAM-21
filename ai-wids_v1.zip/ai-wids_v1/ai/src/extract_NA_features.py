#!/usr/bin/env python3
"""
AI-WIDS Feature Extraction Script

Purpose:
    Extract network features from PCAP files for machine learning IDS training.
    Processes both normal and attack traffic to create labeled dataset.

Input:
    - data/raw/normal/*.pcap (normal traffic)
    - data/raw/test/*.pcap (attack traffic)

Output:
    - data/processed/features.csv (labeled feature dataset)

Features Extracted (24 total):
    - Basic: frame length, timestamp
    - IP: src/dst IP, protocol, TTL
    - TCP: src/dst port, flags, window
    - UDP: length
    - ARP: operation type
    - DNS: query/response flag
    - DHCP: presence
    - Attack indicators: SYN rate, ARP rate, DNS rate

Usage:
    python src/extract_features.py \
        --normal-dir data/raw/normal \
        --test-dir data/raw/test \
        --output data/processed/features.csv
"""

import os
import sys
import argparse
from pathlib import Path
from collections import defaultdict
import pandas as pd

# Try to import scapy
try:
    from scapy.all import rdpcap, IP, TCP, UDP, ARP, DNS, DHCP
except ImportError:
    print("[!] ERROR: scapy not installed")
    print("    Install with: pip install scapy")
    sys.exit(1)

###############################################################################
# GLOBAL TRACKING DICTIONARIES
# 
# These track cumulative behavior across packets to detect patterns
###############################################################################

# Track SYN packets per source IP (DoS indicator)
SYN_COUNTER = defaultdict(int)

# Track ARP packets per source IP (MITM indicator)
ARP_RATE = defaultdict(int)

# Track DNS queries per source IP (DNS flood indicator)
DNS_QUERIES = defaultdict(int)

###############################################################################
# FEATURE EXTRACTION FUNCTION
# 
# Extracts 24 features from a single network packet
###############################################################################

def extract_features(pkt, label="normal"):
    """
    Extract comprehensive features from a single packet.

    Args:
        pkt: Scapy packet object
        label: Traffic label ('normal' or 'attack')

    Returns:
        dict: Dictionary of extracted features
    """

    # Initialize feature dictionary
    features = {}

    ###########################################################################
    # BASIC FEATURES
    ###########################################################################

    # Frame length in bytes
    features['frame_len'] = len(pkt)

    # Timestamp (for temporal analysis)
    features['timestamp'] = float(pkt.time) if hasattr(pkt, 'time') else 0

    ###########################################################################
    # IP LAYER FEATURES
    ###########################################################################

    # Check if packet has IP layer
    features['has_ip'] = int(pkt.haslayer(IP))

    if pkt.haslayer(IP):
        # Source and destination IP addresses
        features['src_ip'] = pkt[IP].src
        features['dst_ip'] = pkt[IP].dst

        # IP protocol (6=TCP, 17=UDP, 1=ICMP, etc.)
        features['ip_proto'] = pkt[IP].proto

        # Time To Live (TTL) - can indicate spoofing
        features['ttl'] = pkt[IP].ttl
    else:
        # Default values if no IP layer
        features['src_ip'] = "0.0.0.0"
        features['dst_ip'] = "0.0.0.0"
        features['ip_proto'] = 0
        features['ttl'] = 0

    ###########################################################################
    # TCP LAYER FEATURES
    ###########################################################################

    # Check if packet has TCP layer
    features['has_tcp'] = int(pkt.haslayer(TCP))

    if pkt.haslayer(TCP):
        # Source and destination ports
        features['src_port'] = pkt[TCP].sport
        features['dst_port'] = pkt[TCP].dport

        # TCP flags (SYN, ACK, RST, etc.)
        # Converted to integer for ML processing
        features['tcp_flags'] = int(pkt[TCP].flags)

        # TCP window size (can indicate anomalies)
        features['tcp_window'] = pkt[TCP].window

        # Individual flag indicators (binary features)
        # SYN flag = connection initiation (flood attacks)
        features['is_syn'] = int(pkt[TCP].flags == 'S')

        # ACK flag = acknowledgment
        features['is_ack'] = int(pkt[TCP].flags == 'A')

        # RST flag = reset (can indicate scanning)
        features['is_rst'] = int(pkt[TCP].flags == 'R')

    else:
        # Default values if no TCP layer
        features['src_port'] = 0
        features['dst_port'] = 0
        features['tcp_flags'] = 0
        features['tcp_window'] = 0
        features['is_syn'] = 0
        features['is_ack'] = 0
        features['is_rst'] = 0

    ###########################################################################
    # UDP LAYER FEATURES
    ###########################################################################

    # Check if packet has UDP layer
    features['has_udp'] = int(pkt.haslayer(UDP))

    if pkt.haslayer(UDP):
        # UDP length
        features['udp_len'] = pkt[UDP].len
    else:
        features['udp_len'] = 0

    ###########################################################################
    # ARP LAYER FEATURES (MITM Detection)
    ###########################################################################

    # Check if packet has ARP layer
    features['has_arp'] = int(pkt.haslayer(ARP))

    if pkt.haslayer(ARP):
        # ARP operation (1=request, 2=reply)
        features['arp_op'] = pkt[ARP].op
    else:
        features['arp_op'] = 0

    ###########################################################################
    # DNS LAYER FEATURES (DNS Flood Detection)
    ###########################################################################

    # Check if packet has DNS layer
    features['has_dns'] = int(pkt.haslayer(DNS))

    if pkt.haslayer(DNS):
        # DNS query/response flag (0=query, 1=response)
        features['dns_qr'] = pkt[DNS].qr
    else:
        features['dns_qr'] = 0

    ###########################################################################
    # DHCP LAYER FEATURES (Reconnect Attack Detection)
    ###########################################################################

    # Check if packet has DHCP layer
    features['has_dhcp'] = int(pkt.haslayer(DHCP))

    ###########################################################################
    # ATTACK INDICATOR FEATURES
    # 
    # These track cumulative behavior to detect attack patterns
    ###########################################################################

    # Track SYN rate per source IP
    # High SYN rate = potential DoS/SYN flood attack
    if features['is_syn']:
        src = features['src_ip']
        SYN_COUNTER[src] += 1
        features['syn_rate'] = SYN_COUNTER[src]
    else:
        features['syn_rate'] = 0

    # Track ARP rate per source IP
    # High ARP rate = potential MITM/ARP spoofing attack
    if features['has_arp']:
        src = features['src_ip']
        ARP_RATE[src] += 1
        features['arp_rate'] = ARP_RATE[src]
    else:
        features['arp_rate'] = 0

    # Track DNS query rate per source IP
    # High DNS rate = potential DNS flood/tunneling attack
    if features['has_dns'] and features['dns_qr'] == 0:  # Query only
        src = features['src_ip']
        DNS_QUERIES[src] += 1
        features['dns_rate'] = DNS_QUERIES[src]
    else:
        features['dns_rate'] = 0

    ###########################################################################
    # LABEL
    ###########################################################################

    # Attach label (normal or attack)
    features['label'] = label

    return features

###############################################################################
# PCAP PROCESSING FUNCTION
# 
# Processes an entire PCAP file and extracts features from all packets
###############################################################################

def process_pcap(pcap_file, label="normal"):
    """
    Process an entire PCAP file and extract features from all packets.

    Args:
        pcap_file (Path): Path to PCAP file
        label (str): Traffic label for this file

    Returns:
        list: List of feature dictionaries (one per packet)
    """

    print(f"[*] Processing: {pcap_file.name} (label={label})")

    # Try to read PCAP file
    try:
        packets = rdpcap(str(pcap_file))
        print(f"    Loaded {len(packets)} packets")
    except Exception as e:
        print(f"[!] Error reading {pcap_file}: {e}")
        return []

    # Extract features from each packet
    features_list = []

    for i, pkt in enumerate(packets):
        # Progress indicator every 1000 packets
        if i % 1000 == 0 and i > 0:
            print(f"    Processed {i} packets...")

        try:
            # Extract features from this packet
            features = extract_features(pkt, label=label)
            features_list.append(features)

        except Exception as e:
            # Skip packets that cause errors (malformed, etc.)
            continue

    print(f"[+] Extracted {len(features_list)} packet features")
    return features_list

###############################################################################
# MAIN FUNCTION
###############################################################################

def main():
    """
    Main execution function.

    Workflow:
        1. Parse command line arguments
        2. Process normal traffic PCAPs
        3. Process attack traffic PCAPs
        4. Combine into single DataFrame
        5. Save as CSV
    """

    # Parse command line arguments
    parser = argparse.ArgumentParser(
        description='AI-WIDS Feature Extraction Pipeline',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Basic usage
    python src/extract_features.py

    # Custom directories
    python src/extract_features.py \
        --normal-dir data/raw/normal \
        --test-dir data/raw/test \
        --output data/processed/features.csv
        """
    )

    parser.add_argument(
        '--normal-dir',
        type=str,
        default='../data/raw/normal',
        help='Directory containing normal traffic PCAPs'
    )

    parser.add_argument(
        '--test-dir',
        type=str,
        default='../data/raw/test',
        help='Directory containing attack traffic PCAPs'
    )

    parser.add_argument(
        '--output',
        type=str,
        default='../data/processed/features.csv',
        help='Output CSV file path'
    )

    args = parser.parse_args()

    # Print banner
    print("╔════════════════════════════════════════════════════════════════╗")
    print("║         AI-WIDS Feature Extraction Pipeline                   ║")
    print("╚════════════════════════════════════════════════════════════════╝")
    print()

    # Initialize list to hold all features
    all_features = []

    ###########################################################################
    # PROCESS NORMAL TRAFFIC
    ###########################################################################

    print("[*] Processing NORMAL traffic...")
    print()

    normal_dir = Path(args.normal_dir)

    if normal_dir.exists():
        # Find all PCAP files in normal directory
        pcap_files = list(normal_dir.glob("*.pcap"))

        if not pcap_files:
            print(f"[!] No PCAP files found in {normal_dir}")
        else:
            print(f"    Found {len(pcap_files)} PCAP files")
            print()

            # Process each PCAP file
            for pcap_file in sorted(pcap_files):
                features = process_pcap(pcap_file, label="normal")
                all_features.extend(features)
                print()
    else:
        print(f"[!] Normal directory not found: {normal_dir}")
        print(f"    Create it with: mkdir -p {normal_dir}")

    print()


    ###########################################################################
    # PROCESS ATTACK TRAFFIC
    ###########################################################################

    print("[*] Processing ATTACK traffic...")
    print()

    test_dir = Path(args.test_dir)

    if test_dir.exists():
        # Find all PCAP files in test directory
        pcap_files = list(test_dir.glob("*.pcap"))

        if not pcap_files:
            print(f"[!] No PCAP files found in {test_dir}")
        else:
            print(f"    Found {len(pcap_files)} PCAP files")
            print()

            # Process each PCAP file
            for pcap_file in sorted(pcap_files):
                features = process_pcap(pcap_file, label="attack")
                all_features.extend(features)
                print()
    else:
        print(f"[!] Attack directory not found: {test_dir}")
        print(f"    Create it with: mkdir -p {test_dir}")

    print()

    ###########################################################################
    # CREATE DATAFRAME AND SAVE
    ###########################################################################

    if not all_features:
        print("[!] ERROR: No features extracted")
        print("    Make sure PCAP files exist in:")
        print(f"      - {normal_dir}")
        print(f"      - {test_dir}")
        sys.exit(1)

    # Convert list of dicts to pandas DataFrame
    df = pd.DataFrame(all_features)

    # Print summary statistics
    print("═" * 70)
    print("  Feature Extraction Summary")
    print("═" * 70)
    print(f"Total packets: {len(df):,}")
    print(f"Features: {len(df.columns) - 1}")  # -1 for label column
    print()

    print("Label distribution:")
    label_counts = df['label'].value_counts()
    for label, count in label_counts.items():
        pct = 100 * count / len(df)
        print(f"  {label:10s}: {count:6,} ({pct:5.1f}%)")
    print()

    # Check data balance
    if len(label_counts) == 2:
        min_pct = 100 * label_counts.min() / len(df)
        if min_pct < 30:
            print(f"[!] WARNING: Imbalanced data (minority class: {min_pct:.1f}%)")
            print("    Recommend: 40-60% for each class")
            print()

    # Attack indicator summary
    print("Attack indicator summary:")
    print(f"  High SYN rate (>50):  {(df['syn_rate'] > 50).sum():6,} packets")
    print(f"  High ARP rate (>10):  {(df['arp_rate'] > 10).sum():6,} packets")
    print(f"  High DNS rate (>20):  {(df['dns_rate'] > 20).sum():6,} packets")
    print()

    # Save to CSV
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    df.to_csv(output_path, index=False)

    print(f"[+] Features saved to: {output_path}")
    print(f"[+] Shape: {df.shape} (rows × columns)")
    print()

    # Next steps
    print("═" * 70)
    print("  Next Steps")
    print("═" * 70)
    print("1. Train model:")
    print("   python src/train_model.py")
    print()
    print("2. Evaluate model:")
    print("   python src/evaluate_model.py")
    print()
    print("3. Live detection:")
    print("   python src/live_detection.py")
    print()

###############################################################################
# ENTRY POINT
###############################################################################

if __name__ == "__main__":
    main()
