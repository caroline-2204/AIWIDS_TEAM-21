from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/')
def home():
    return "Server is running"

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    print("Received:", data)
    return jsonify({"status": "received", "data": data})

if __name__ == '__main__':
    app.run(host='192.168.32.10', port=8000)
